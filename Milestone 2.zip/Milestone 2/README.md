# Hotel Recommendation System — RAG Pipeline
## Milestone 1: Schema Design, DDL & SQL Queries

**Authors:** Emmanuel Mukange (ZDA24B029) · Raudhat Ramadhan (ZDA24B010)  
**Course:** Database Management Systems — IIT Madras Zanzibar  
**Track:** A — RAG Pipeline (Retrieval-Augmented Generation)  


## 1. Project Overview

This project builds a hotel recommendation and question-answering system that combines a normalised relational database (PostgreSQL) with a vector search layer (Pinecone). Real hotel data from Kaggle forms the foundation, extended with synthetically generated users, bookings, and reviews to exceed the 1,000-row minimum.

---

## 2. Files in This Submission

| File | Description |
|------|-------------|
| `schema.sql` | Complete DDL: DROP, CREATE TABLE, indexes, and all INSERT statements. Runs from scratch with a single `psql` command. |
| `queries.sql` | Ten labelled SQL queries covering all required query types (see §6). |
| `README.md` | This document — data dictionary, import steps, query descriptions, and reproduction instructions. |

> **Note:** Data is embedded directly in `schema.sql` as INSERT statements. A separate `data.csv` is not required because the schema file is self-contained and reproducible.

---

## 3. Row Counts (Track A minimum: 1,000 rows)

| Table | Source | Row Count |
|-------|--------|-----------|
| `room_types` | Manual | 5 |
| `hotels` | Kaggle (real) | 474 |
| `users` | Synthetic (Faker, seed 42) | 150 |
| `bookings` | Synthetic (Faker, seed 42) | 450 |
| `reviews` | Synthetic (Faker, seed 42) | 474 |
| **TOTAL** | | **1,553** ✓ |

---

## 4. Data Dictionary

### 4.1 `room_types` — Room category lookup

| Column | Type | Constraints | Description | Allowed Values / Range |
|--------|------|-------------|-------------|------------------------|
| `room_type_id` | SERIAL | PK | Surrogate primary key, auto-incremented | 1–5 |
| `type_name` | VARCHAR(50) | UNIQUE NOT NULL | Human-readable room label | Single, Double, Twin, Suite, Penthouse |
| `max_occupancy` | SMALLINT | CHECK (1–10) | Maximum guests permitted | 1–10 |
| `price_multiplier` | NUMERIC(4,2) | CHECK (>0) | Factor applied to `hotels.price_per_night` | 0.80–3.00 |

### 4.2 `hotels` — Core hotel master records

| Column | Type | Constraints | Description | Allowed Values / Range |
|--------|------|-------------|-------------|------------------------|
| `hotel_id` | SERIAL | PK | Surrogate primary key | Auto-assigned |
| `name` | VARCHAR(200) | NOT NULL | Official hotel name (from Kaggle) | Any non-empty string |
| `city` | VARCHAR(100) | NOT NULL | City name extracted from Kaggle locality | Text |
| `state` | CHAR(2) | NOT NULL | US state abbreviation | e.g. FL, NY, CA |
| `zip_code` | VARCHAR(10) | — | Postal code | US ZIP format |
| `address` | VARCHAR(255) | — | Street address | Text |
| `phone` | VARCHAR(20) | — | Contact phone number | Digits, may include formatting |
| `website` | VARCHAR(500) | — | Hotel website URL | Valid URL or NULL |
| `category` | VARCHAR(50) | NOT NULL | Market segment | Budget, Mid-range, Boutique, Luxury, Resort |
| `star_rating` | NUMERIC(2,1) | CHECK (1.0–5.0) | Aggregate star rating (synthetic) | 1.0–5.0 |
| `price_per_night` | NUMERIC(8,2) | CHECK (>0) | Base nightly rate in USD (synthetic) | $45–$550 |
| `amenities` | TEXT | — | Comma-separated amenity list — RAG text corpus | Free text |
| `total_rooms` | SMALLINT | CHECK (>0) | Total room inventory (synthetic) | 20–400 |
| `created_at` | TIMESTAMPTZ | DEFAULT now() | Row creation timestamp (UTC) | Any valid timestamp |

### 4.3 `users` — Application users / travellers

| Column | Type | Constraints | Description | Allowed Values / Range |
|--------|------|-------------|-------------|------------------------|
| `user_id` | SERIAL | PK | Surrogate primary key | Auto-assigned |
| `first_name` | VARCHAR(100) | NOT NULL | Given name | Text |
| `last_name` | VARCHAR(100) | NOT NULL | Family name | Text |
| `email` | VARCHAR(255) | UNIQUE NOT NULL | Login identifier and candidate key | Valid email format |
| `phone` | VARCHAR(20) | — | Contact phone | Digits |
| `nationality` | VARCHAR(100) | — | Country of citizenship (informational) | 15-country pool |
| `date_of_birth` | DATE | — | User date of birth | 1940-01-01 to 2006-12-31 |
| `created_at` | DATE | DEFAULT CURRENT_DATE | Registration date | Any valid date |

### 4.4 `bookings` — Hotel reservations (fact table)

| Column | Type | Constraints | Description | Allowed Values / Range |
|--------|------|-------------|-------------|------------------------|
| `booking_id` | SERIAL | PK | Surrogate primary key | Auto-assigned |
| `user_id` | INT | FK → users, CASCADE | Guest who made the booking | Valid user_id |
| `hotel_id` | INT | FK → hotels, RESTRICT | Hotel booked | Valid hotel_id |
| `room_type_id` | INT | FK → room_types | Room category booked | 1–5 |
| `check_in_date` | DATE | NOT NULL | Arrival date | Any valid date |
| `check_out_date` | DATE | NOT NULL, > check_in | Departure date | Any date after check_in |
| `num_guests` | SMALLINT | CHECK (≥1) | Number of guests | 1–4 |
| `total_price` | NUMERIC(10,2) | CHECK (≥0) | Total charge in USD (locked at booking time) | ≥ 0 |
| `status` | VARCHAR(20) | CHECK (enum) | Booking lifecycle state | confirmed, cancelled, completed, no_show |
| `created_at` | DATE | DEFAULT CURRENT_DATE | Booking creation date | Any valid date |

### 4.5 `reviews` — Hotel reviews (RAG text corpus)

| Column | Type | Constraints | Description | Allowed Values / Range |
|--------|------|-------------|-------------|------------------------|
| `review_id` | SERIAL | PK | Surrogate primary key | Auto-assigned |
| `hotel_id` | INT | FK → hotels, CASCADE | Hotel being reviewed | Valid hotel_id |
| `user_id` | INT | FK → users, SET NULL | Reviewer (NULL if user deleted) | Valid user_id or NULL |
| `rating` | NUMERIC(2,1) | CHECK (1.0–5.0) | User-submitted star rating | 1.0–5.0 |
| `review_text` | TEXT | NOT NULL | Full review body — feeds RAG embedding pipeline | 6–10 sentences |
| `review_date` | DATE | DEFAULT CURRENT_DATE | Date review was written | Any valid date |
| `helpful_votes` | INT | CHECK (≥0) | Community upvotes on the review | 0–150 |

---

## 5. Import Steps — Loading Data into PostgreSQL

### Prerequisites

- PostgreSQL 15 or later installed and running
- A target database already created (e.g. `hotel_rag`)
- The `schema.sql` file from this submission

### Step 1 — Create the database (if it does not exist)

```bash
psql -U postgres -c "CREATE DATABASE hotel_rag;"
```

### Step 2 — Run the schema file (DDL + all data)

```bash
psql -U postgres -d hotel_rag -f schema.sql
```

This single command executes:
1. `DROP TABLE IF EXISTS` (safe re-run)
2. `CREATE TABLE` for all five tables with constraints and indexes
3. `INSERT INTO` for all 1,553 rows of data

### Step 3 — Verify row counts

```sql
SELECT 'room_types' AS tbl, COUNT(*) FROM room_types
UNION ALL
SELECT 'hotels',   COUNT(*) FROM hotels
UNION ALL
SELECT 'users',    COUNT(*) FROM users
UNION ALL
SELECT 'bookings', COUNT(*) FROM bookings
UNION ALL
SELECT 'reviews',  COUNT(*) FROM reviews;
```

Expected output:

```
    tbl     | count
------------+-------
 room_types |     5
 hotels     |   474
 users      |   150
 bookings   |   450
 reviews    |   474
```

### Step 4 — Run the queries

```bash
psql -U postgres -d hotel_rag -f queries.sql
```

---

## 6. Query Coverage

All ten queries are in `queries.sql`. Each is labelled with a tag at the top of its comment block.

| Label | Type | Query Description |
|-------|------|-------------------|
| `[AGG-1]` | Aggregation | Total and average booking revenue grouped by hotel category |
| `[AGG-2]` | Aggregation | Average review rating per city, filtered to cities with ≥5 reviews |
| `[JOIN-1]` | Join | Full booking ledger joining bookings, users, hotels, and room_types |
| `[JOIN-2]` | Join | Top-reviewed hotels combining hotels and reviews aggregates |
| `[SUB-1]` | Subquery | Hotels with price_per_night above the portfolio-wide average (scalar subquery) |
| `[SUB-2]` | Subquery | Users who have never made a booking (correlated NOT EXISTS subquery) |
| `[CTE-1]` | CTE | Monthly booking revenue trend with month-over-month change |
| `[CTE-2]` | CTE | Hotel revenue tier classification using two chained CTEs |
| `[WIN-1]` | Window function | Booking revenue ranked within each hotel category using RANK() |
| `[WIN-2]` | Window function | Running cumulative booking count and spend per user using SUM() OVER |

---

## 7. Design Decisions

### Why amenities is a flat text column
The `amenities` column in `hotels` is stored as a comma-separated string rather than a junction table. This is intentional: the column is the primary text corpus for the sentence-transformer embedding pipeline. Splitting it into rows would destroy the semantic continuity needed for accurate vector retrieval. SQL never filters on individual amenities in this system.

### Why total_price is stored redundantly in bookings
`total_price` is derivable from `price_per_night * price_multiplier * nights`, but hotel prices change over time. Storing the price at booking time is standard practice in reservation systems — it ensures historical accuracy and is not a 3NF violation because the value is an atomic fact of the booking event, not a transitive dependency.

### Vector store — Pinecone instead of pgvector
PostgreSQL 18 does not have a prebuilt pgvector binary for all platforms. The specification permits using Pinecone when pgvector is unavailable. All relational data remains in PostgreSQL; only the 384-dimensional sentence-transformer embeddings are stored in Pinecone.

---

## 8. Reproducibility

The synthetic data (users, bookings, reviews) was generated with `random.seed(42)` and `Faker.seed(42)`. Running the generator script on any machine produces byte-identical INSERT statements. The `schema.sql` file is therefore the single source of truth — no external data files are required.

